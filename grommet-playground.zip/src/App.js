import React, {Component, useState} from 'react';
import { 
  Grommet, 
  Heading, 
  Box, 
  Paragraph, 
  Accordion, 
  AccordionPanel, 
  Text, 
  Button as BasicButton,
  TextInput,
} from 'grommet';
import * as Icons from "grommet-icons";
import styled from "styled-components";
import { EditableText } from "@blueprintjs/core";
//import "@blueprintjs/core/lib/css/blueprint.css";
import EditText from "./components/EditText";

const Button = styled(BasicButton)`
  width: ${props => props.width};
`;

function App() {
  const [value, setValue] = useState();
  return (
    <Grommet>
      <Box background="light-2" pad="medium">
        <Heading>
          Welcome, to&nbsp; 
          <Box 
            background="brand" 
            pad="small" 
            flex="shrink" 
            width="large" 
            style={{display: 'inline-flex'}}
          >
            <EditText
              placeholder="URL.DEV"
              color="red"
            />
          </Box>
        </Heading>
        <Box pad="small" border={{color: "light-5", size: "large"}} width="large">
          <Paragraph size="large">
            With URL.DEV, you'll get the most bang-for-your-bargain with our intense link-management pattern. Enter a URL below to get started:
          </Paragraph>
          <Box 
            margin={{
              bottom: "small"
            }}
            direction="row"
          >
            <TextInput 
              placeholder="https://github.com/kari-labs"
            />
            <Button
              icon={<Icons.Contract />}
              label="Shorten"
              onClick={() => {}}
              width="max-content"
              primary
              color="accent-1"
              reverse
              margin={{
                left: "small"
              }}
              style={{
                borderRadius: "5px"
              }}
            />
          </Box>
          <EditText/>
        </Box>
        <Box background="light-3" width="100%" margin={{vertical: "medium"}} border={{color: "light-5", size: "medium"}}>
          <Accordion>
            <AccordionPanel label="Panel 1">
              <Box pad="medium" background="light-2">
                <Text>One</Text>
              </Box>
            </AccordionPanel>
            <AccordionPanel label="Panel 2">
              <Box pad="medium" background="light-2">
                <Text>Two</Text>
              </Box>
            </AccordionPanel>
          </Accordion>
        </Box>
        
      </Box>
    </Grommet>
  );
}

export default App;
